mod voice;
use serde::{Deserialize, Serialize};
use std::{env, sync::Mutex, time::Instant};
use sysinfo::{CpuRefreshKind, MemoryRefreshKind, RefreshKind, System};
use tauri::Manager;

struct MetricsSampler {
    system: System,
    last_cpu_sample: Instant,
    cpu_percent: Option<f32>,
}
struct MetricsState(Mutex<MetricsSampler>);

#[derive(Serialize)]
struct SystemMetrics {
    cpu_percent: Option<f32>,
    ram_used_gb: Option<f64>,
    ram_total_gb: Option<f64>,
    gpu_percent: Option<f32>,
    cpu_temp_c: Option<f32>,
    gpu_temp_c: Option<f32>,
    os_name: String,
    cpu_name: String,
}

#[derive(Serialize)]
struct AiStatus { ready: bool, provider: &'static str }

#[derive(Serialize)]
struct GroqRequest { model: String, messages: Vec<ChatMessage>, temperature: f32, max_tokens: u32 }
#[derive(Serialize)]
struct ChatMessage { role: &'static str, content: String }
#[derive(Deserialize)]
struct GroqResponse { choices: Vec<GroqChoice> }
#[derive(Deserialize)]
struct GroqChoice { message: GroqReply }
#[derive(Deserialize)]
struct GroqReply { content: Option<String> }

fn configured_keys() -> Vec<String> {
    ["GROQ_API_KEY_1", "GROQ_API_KEY_2"].iter()
        .filter_map(|name| env::var(name).ok())
        .filter(|key| !key.trim().is_empty())
        .collect()
}

#[tauri::command]
fn get_ai_status() -> AiStatus { AiStatus { ready: !configured_keys().is_empty(), provider: "Groq" } }

#[tauri::command]
fn get_system_metrics(state: tauri::State<'_, MetricsState>) -> Result<SystemMetrics, String> {
    let mut sampler = state.0.lock().map_err(|_| "Systemmonitor nicht verfügbar".to_string())?;
    // CPU usage is a delta between two samples. Never expose the warm-up value.
    if sampler.last_cpu_sample.elapsed() >= sysinfo::MINIMUM_CPU_UPDATE_INTERVAL {
        sampler.system.refresh_cpu_usage();
        sampler.cpu_percent = if sampler.system.cpus().is_empty() { None } else {
            let value = sampler.system.global_cpu_usage();
            (value.is_finite() && (0.0..=100.0).contains(&value)).then_some(value)
        };
        sampler.last_cpu_sample = Instant::now();
    }
    let cpu_percent = sampler.cpu_percent;
    let sys = &mut sampler.system;
    sys.refresh_memory();
    let total = sys.total_memory();
    let (ram_used_gb, ram_total_gb) = if total == 0 { (None, None) } else {
        (Some(sys.used_memory() as f64 / 1_073_741_824.0), Some(total as f64 / 1_073_741_824.0))
    };
    Ok(SystemMetrics {
        cpu_percent, ram_used_gb, ram_total_gb,
        // No hardware provider is integrated for these values: never invent readings.
        gpu_percent: None, cpu_temp_c: None, gpu_temp_c: None,
        os_name: System::long_os_version().unwrap_or_else(|| "Nicht verfügbar".into()),
        cpu_name: sys.cpus().first().map(|cpu| cpu.brand().to_string()).unwrap_or_else(|| "Nicht verfügbar".into()),
    })
}

#[tauri::command]
async fn chat_with_groq(message: String) -> Result<String, String> {
    let message = message.trim();
    if message.is_empty() || message.chars().count() > 8000 { return Err("Nachricht muss 1 bis 8.000 Zeichen enthalten.".into()); }
    let keys = configured_keys();
    if keys.is_empty() { return Err("Kein Groq-Key eingerichtet. Bitte lokale .env konfigurieren und neu starten.".into()); }
    let model = env::var("GROQ_MODEL").unwrap_or_else(|_| "llama-3.3-70b-versatile".into());
    let payload = GroqRequest { model, temperature: 0.6, max_tokens: 1200, messages: vec![
        ChatMessage { role: "system", content: "Du bist J.A.R.V.I.S., ein hilfreicher, sachlicher und freundlicher persönlicher Assistent. Antworte standardmäßig auf Deutsch. Gib klare, gut strukturierte Antworten.".into() },
        ChatMessage { role: "user", content: message.to_string() },
    ] };
    let client = reqwest::Client::builder().timeout(std::time::Duration::from_secs(45)).build()
        .map_err(|_| "HTTP-Client konnte nicht gestartet werden.".to_string())?;
    let mut last_error = "Groq-Anfrage fehlgeschlagen.".to_string();
    for key in keys {
        let response = client.post("https://api.groq.com/openai/v1/chat/completions")
            .bearer_auth(key).json(&payload).send().await;
        match response {
            Ok(resp) if resp.status().is_success() => {
                let parsed: GroqResponse = resp.json().await.map_err(|_| "Unerwartete Groq-Antwort.".to_string())?;
                return parsed.choices.into_iter().next().and_then(|c| c.message.content)
                    .ok_or_else(|| "Groq hat keine Textantwort geliefert.".into());
            }
            Ok(resp) => {
                let code = resp.status();
                last_error = format!("Groq meldet HTTP {}. Prüfe API-Key, Modell und Kontingent.", code.as_u16());
                if !matches!(code.as_u16(), 401 | 403 | 429) { break; }
            }
            Err(_) => { last_error = "Groq ist nicht erreichbar oder die Anfrage hat zu lange gedauert.".into(); break; }
        }
    }
    Err(last_error)
}

pub fn run() {
    // Load only from the user's local config directory, never from the frontend bundle.
    if let Some(config_dir) = dirs_config_path() {
        let _ = dotenvy::from_path(config_dir.join(".env"));
    }
    tauri::Builder::default()
        .manage(voice::VoiceState::default())
        .on_window_event(|window, event| {
            match event {
                tauri::WindowEvent::Focused(false) => window.state::<voice::VoiceState>().cancel(None, true),
                tauri::WindowEvent::Destroyed => window.state::<voice::VoiceState>().cancel(None, false),
                _ => {},
            }
        })
        .setup(|app| {
            let sys = System::new_with_specifics(RefreshKind::nothing()
                .with_cpu(CpuRefreshKind::everything())
                .with_memory(MemoryRefreshKind::everything()));
            app.manage(MetricsState(Mutex::new(MetricsSampler {
                system: sys, last_cpu_sample: Instant::now(), cpu_percent: None,
            })));
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![get_system_metrics, get_ai_status, chat_with_groq, voice::voice_capabilities, voice::voice_permission, voice::voice_start, voice::voice_snapshot, voice::voice_finish, voice::voice_cancel])
        .run(tauri::generate_context!())
        .expect("J.A.R.V.I.S. konnte nicht gestartet werden");
}

fn dirs_config_path() -> Option<std::path::PathBuf> {
    // Windows: %APPDATA%\\JARVIS\\.env; Linux/macOS fallback for development.
    #[cfg(windows)] { env::var_os("APPDATA").map(|p| std::path::PathBuf::from(p).join("JARVIS")) }
    #[cfg(not(windows))] { env::var_os("HOME").map(|p| std::path::PathBuf::from(p).join(".config").join("JARVIS")) }
}
