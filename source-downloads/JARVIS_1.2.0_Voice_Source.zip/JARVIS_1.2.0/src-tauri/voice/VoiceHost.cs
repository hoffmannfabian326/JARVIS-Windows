// C# 5 / .NET Framework: compatible with Windows PowerShell 5.1 Add-Type.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Speech.Recognition;
using System.Speech.Synthesis;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace JarvisVoice {
    public static class Host {
        private static readonly object OutputLock = new object();
        private static readonly JavaScriptSerializer Json = new JavaScriptSerializer();
        private static void Emit(object value) {
            lock (OutputLock) { Console.WriteLine(Json.Serialize(value)); Console.Out.Flush(); }
        }
        private static List<object> Voices(SpeechSynthesizer synth) {
            var voices = new List<object>();
            foreach (InstalledVoice installed in synth.GetInstalledVoices()) {
                VoiceInfo info = installed.VoiceInfo;
                // Use built-in Microsoft desktop voices; never select a cloud voice/provider.
                if (installed.Enabled && info.Culture.Name == "de-DE" && info.Name.StartsWith("Microsoft ", StringComparison.Ordinal))
                    voices.Add(new { id = info.Name, name = info.Name, gender = info.Gender.ToString(), culture = info.Culture.Name });
            }
            return voices;
        }
        private static RecognizerInfo GermanRecognizer() {
            foreach (RecognizerInfo info in SpeechRecognitionEngine.InstalledRecognizers())
                if (info.Culture.Name == "de-DE") return info;
            return null;
        }
        public static void Run(string request) {
            try {
                var data = Json.Deserialize<Dictionary<string, object>>(request);
                string mode = (string)data["mode"];
                if (mode == "probe") {
                    var voices = new List<object>();
                    bool recognition = false;
                    try { using (var synth = new SpeechSynthesizer()) { voices = Voices(synth); } } catch (Exception) { }
                    try { recognition = GermanRecognizer() != null; } catch (Exception) { }
                    Emit(new { type = "capabilities", available = true, voices = voices, recognition = recognition, note = "Lokales System.Speech / de-DE. Desktop-Mikrofonzugriff muss in Windows erlaubt sein." });
                } else if (mode == "listen") Listen();
                else if (mode == "speak") Speak(data);
                else throw new ArgumentException();
            } catch (Exception) {
                Emit(new { type = "error", error = "Lokale Sprachengine nicht verfuegbar. Installierte deutsche Desktop-Sprachpakete, Mikrofonrechte und Audiogeraet pruefen." });
            }
        }
        private static void Speak(Dictionary<string, object> data) {
            using (var synth = new SpeechSynthesizer()) {
                string selected = (string)data["voice"];
                bool valid = false;
                foreach (InstalledVoice installed in synth.GetInstalledVoices()) {
                    var voice = installed.VoiceInfo;
                    if (installed.Enabled && voice.Culture.Name == "de-DE" && voice.Name.StartsWith("Microsoft ", StringComparison.Ordinal) && voice.Name == selected) valid = true;
                }
                if (!valid) throw new ArgumentException();
                synth.SelectVoice(selected);
                synth.Volume = Convert.ToInt32(data["volume"], CultureInfo.InvariantCulture);
                synth.Rate = Convert.ToInt32(data["rate"], CultureInfo.InvariantCulture);
                synth.SetOutputToDefaultAudioDevice();
                // Plain text, never SSML/code supplied by a chat response.
                using (var done = new ManualResetEvent(false)) {
                    bool failed = false;
                    synth.SpeakCompleted += delegate(object sender, SpeakCompletedEventArgs e) { failed = e.Error != null; done.Set(); };
                    synth.SpeakStarted += delegate { Emit(new { type = "speaking" }); };
                    synth.SpeakAsync((string)data["text"]);
                    if (!done.WaitOne(TimeSpan.FromMinutes(3))) {
                        synth.SpeakAsyncCancelAll();
                        Emit(new { type = "error", error = "Sprachausgabe nach drei Minuten beendet." });
                    } else if (failed) Emit(new { type = "error", error = "Lokale Sprachausgabe fehlgeschlagen." });
                    else Emit(new { type = "complete", transcript = "" });
                }
            }
        }
        private static void Listen() {
            RecognizerInfo info = GermanRecognizer();
            if (info == null) throw new InvalidOperationException();
            // One control line: finish or EOF. Rust kills the process on cancellation.
            Task<string> control = Task.Factory.StartNew(delegate { return Console.ReadLine(); });
            using (var recognizer = new SpeechRecognitionEngine(info))
            using (var done = new ManualResetEvent(false)) {
                var textLock = new object();
                string transcript = "";
                bool failed = false;
                var levelClock = Stopwatch.StartNew();
                recognizer.LoadGrammar(new DictationGrammar());
                recognizer.SpeechRecognized += delegate(object sender, SpeechRecognizedEventArgs e) {
                    lock (textLock) {
                        string next = (transcript + " " + e.Result.Text).Trim();
                        if (next.Length <= 8000) transcript = next;
                    }
                };
                recognizer.AudioLevelUpdated += delegate(object sender, AudioLevelUpdatedEventArgs e) {
                    if (levelClock.ElapsedMilliseconds >= 80) {
                        Emit(new { type = "level", level = e.AudioLevel }); levelClock.Restart();
                    }
                };
                recognizer.RecognizeCompleted += delegate(object sender, RecognizeCompletedEventArgs e) { failed = e.Error != null; done.Set(); };
                // A short tap released during engine initialization never opens the microphone.
                if (control.IsCompleted) { Emit(new { type = "complete", transcript = "" }); return; }
                recognizer.SetInputToDefaultAudioDevice();
                try {
                    recognizer.RecognizeAsync(RecognizeMode.Multiple);
                    Emit(new { type = "listening" });
                    var clock = Stopwatch.StartNew();
                    while (!control.IsCompleted && !done.WaitOne(40) && clock.Elapsed < TimeSpan.FromSeconds(30)) { }
                    if (!done.WaitOne(0)) {
                        recognizer.RecognizeAsyncStop();
                        if (!done.WaitOne(2000)) { recognizer.RecognizeAsyncCancel(); done.WaitOne(500); failed = true; }
                    }
                } finally { recognizer.SetInputToNull(); }
                if (failed) Emit(new { type = "error", error = "Spracherkennung wurde ohne gueltiges Ergebnis beendet." });
                else { lock (textLock) Emit(new { type = "complete", transcript = transcript }); }
            }
        }
    }
}
