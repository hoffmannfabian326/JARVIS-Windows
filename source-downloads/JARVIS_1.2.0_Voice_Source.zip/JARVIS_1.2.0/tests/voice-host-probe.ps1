# Windows-only local smoke check. Enumerates providers; NEVER opens the microphone.
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
$hostScript = Join-Path $projectRoot 'src-tauri\voice\launch.ps1'
$hostSource = Join-Path $projectRoot 'src-tauri\voice\VoiceHost.cs'
'{"mode":"probe"}' | & "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $hostScript -Source $hostSource
