# J.A.R.V.I.S. 1.2.0 — HUD Command Center

React 19 / TypeScript / Tauri 2 / Rust. Überarbeitung des bereitgestellten
1.1.0-Quellprojekts anhand des vom Nutzer beigefügten HUD-Bildes.

## Oberfläche

- Futuristische Statusleiste mit echter lokaler Uhr und getrenntem Backend-Status.
- Linke Navigation zu Command Center, Systemmonitor, KI Intelligence, WoW Forever,
  Aktivitätsprotokoll und Einstellungen.
- Zentraler Arc-Reactor mit animierten Ringen, holografischer SVG-Weltkugel,
  Orbitlinien und HUD-Raster. Ausschließlich dekorativ, keine Live-Netzwerkkarte.
- CPU-, GPU-, RAM- und Laufwerksanzeigen, Messverlauf und Systemstatus.
- Schnellaktionen für Chat-Fokus, neue Abfrage, Systemdetails und Konfiguration.
- Rechter KI-Chat über den vorhandenen Groq-Befehl; keine automatischen KI-Antworten.
- Lokale deutsche Voice Engine mit installierten Windows-Stimmen, Push-to-Talk, Mikrofonfreigabe und echten Eingangspegeln am Reactor.
- Unterer News-Ticker mit ehrlichem Quellenstatus; keine erfundenen Nachrichten.
- Responsive Darstellung und Navigation, Tastaturbedienung, sichtbare Fokusmarkierung,
  Sprunglink und automatische Unterstützung für `prefers-reduced-motion`.

Browser-Vorschau ohne Tauri-Backend: [HUD-Preview.png](docs/HUD-Preview.png).
Alle Messwerte dieser Vorschau sind ausdrücklich „Nicht verfügbar“.

## Datenquellen und Grenzen

`get_system_metrics` liefert CPU und RAM über Rust/sysinfo. GPU-Auslastung und
CPU-/GPU-Temperaturen bleiben wie in 1.1.0 `None`, bis ein echter Anbieter integriert
wird. Laufwerksbelegung ist nicht Bestandteil der vorhandenen Schnittstelle und wird
als „Nicht verfügbar“ angezeigt. **Keine neue Sensorintegration ist Teil dieses UI-Updates.**
RAM wird korrekt in GiB bezeichnet. 0 ist ein gültiger Messwert; fehlende, nicht endliche
oder ungültige Werte werden nicht in 0 umgewandelt. Fehlerhafte Messungen entfernen
aktuelle Hardwarewerte und erzeugen Lücken im Verlauf. Die letzte erfolgreiche
Abfrage wird bei einem späteren Fehler als veraltet gekennzeichnet.

Abfragen erfolgen ohne Überlappung, vier Sekunden nach Abschluss des vorigen
Abfragezyklus. Der Verlauf ist auf 45 Abfragen begrenzt. Die CPU-Anlaufmessung im
Rust-Backend wird erst nach dem von sysinfo geforderten Mindestintervall freigegeben.
Die Uhr wird separat gerendert; Reactor und Globe sind memoisiert. Es werden keine
WebGL-Bibliotheken, externen Schriften oder Bilddownloads benötigt.

`get_ai_status` bestätigt nur eine vorhandene Konfiguration. Die Oberfläche behauptet
keine Online-Verbindung zu Groq. Ein echter Verbindungsversuch erfolgt erst beim
Senden. News ist nicht angebunden. Die lokale Sprachsteuerung ist im folgenden Abschnitt dokumentiert. Das Aktivitätsprotokoll
enthält nur tatsächlich ausgelöste App-Ereignisse der aktuellen Sitzung.

## Entwicklung

Windows 10/11 x64: Rust/MSVC, Windows SDK und C++ Build Tools sowie WebView2.
Für Frontend und mitgelieferte Node-Tests Node.js 22.6+ (empfohlen: aktuelles LTS).

```powershell
npm ci
npm run check
npm run build
npm test
cargo check --manifest-path src-tauri/Cargo.toml
npm run tauri dev
```

`npm run build` erstellt nur das Web-Frontend. Für diese Lieferung wurde **kein
Installer erstellt**. Die bestehende Bundlekonfiguration wurde beibehalten.

Browserprüfungen:

```powershell
npx playwright install chromium
npm run test:ui
```

Optional eine vorhandene Chromium-Datei über `PLAYWRIGHT_CHROMIUM_EXECUTABLE`
auswählen. Die Tests starten einen Vite-Server auf Port 1422. Die synthetischen
IPC-Testantworten stehen ausschließlich unter `tests/browser`; sie gehören nicht
zur produktiven Oberfläche und sind keine Hardwaremessungen.

## Groq-Konfiguration (unverändert)

`%APPDATA%\JARVIS\.env` entsprechend `.env.example` anlegen oder die
Prozessvariablen `GROQ_API_KEY_1`, `GROQ_API_KEY_2`, `GROQ_MODEL` setzen.
Danach die App neu starten. Unter Linux/macOS gilt für die Entwicklung der bestehende
Pfad `$HOME/.config/JARVIS/.env`.

Schlüssel werden ausschließlich im Rust-Backend gelesen, niemals an React übertragen.
`chat_with_groq` behält Eingabelimit, Modellwahl, HTTP-Timeout sowie den
Primär-/Ersatzschlüsselwechsel bei HTTP 401/403/429 bei. Eine gültige Konfiguration
bestätigt weder Gültigkeit des Schlüssels noch Erreichbarkeit oder Kontingent.

Änderungen und genaue Prüfergebnisse: [CHANGELOG_1.2.0.md](CHANGELOG_1.2.0.md).

## Lokale Voice Engine (Erweiterung von 1.2.0)

Die rechte Chatspalte enthält die Mikrofonfreigabe und Push-to-Talk. Unter
„Stimme & Sprachausgabe“ lassen sich vorhandene deutsche Desktopstimmen,
Lautstärke und Sprechgeschwindigkeit auswählen. Sprachausgabe ist zunächst aus.
Eine installierte männliche Stimme wird bevorzugt; ruhiges Standardtempo: −2.

Audio wird lokal mit Windows-System.Speech verarbeitet. Ein lokaler de-DE-Erkenner
ist erforderlich. Sprache erscheint erst als bearbeitbarer Chatentwurf; nur die
bewusste Sendebestätigung überträgt Text an den bestehenden Groq-Befehl. Keine
Aufnahmedateien und kein Cloud-STT-Fallback. Escape, Loslassen und Abbruch sowie
Fokusverlust und maximal 30 Sekunden begrenzen die Aufnahme.

**Voraussetzungen, Architektur, NSIS-Kompatibilitätsentscheidung, Tastaturbedienung,
Datenschutzgrenzen und Windows-Prüfplan:** [docs/VOICE_ENGINE.md](docs/VOICE_ENGINE.md).
Der lokale Hilfsprozess benötigt Windows PowerShell 5.1/System.Speech. Fehlen
Erkenner oder Stimmen, zeigt die App deren tatsächliche Verfügbarkeit statt eines
simulierten Sprachbetriebs. Ein nativer Windows-Audiotest steht weiterhin aus.
Es wurde auch für diese Erweiterung kein Installer erstellt.
