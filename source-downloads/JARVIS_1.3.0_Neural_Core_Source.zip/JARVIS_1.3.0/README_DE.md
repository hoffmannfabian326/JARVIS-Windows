# J.A.R.V.I.S. 1.3.0 — Neural Intelligence Core

Überprüfbarer Entwicklungsstand für Windows x64 mit React/TypeScript, Tauri 2,
Rust und lokalem SQLite/FTS5. Arc-Reactor-HUD, echte Hardwareanzeigen und deutsche
Voice Engine aus 1.2 bleiben erhalten. **Kein Installer und kein App-Release.**

## Windows-Entwicklung

Voraussetzungen: Windows 10/11 x64, aktuelles Node-LTS (mindestens 22.6 für die
mitgelieferten Node-Tests), Rust/MSVC, C++ Build Tools und Windows SDK, WebView2.
Für lokale Sprache zusätzlich Windows PowerShell 5.1/System.Speech sowie tatsächlich
installierte deutsche Desktop-SAPI-Stimmen und -Erkenner; siehe `docs/VOICE_ENGINE.md`.

```powershell
npm ci
npm run check
npm run build
npm test
cargo test --manifest-path crates/neural-core/Cargo.toml --locked
cargo check --manifest-path src-tauri/Cargo.toml --locked
npm run tauri dev
```

`npm run build` erzeugt nur das React-Frontend. Ein Windows-x64-Installer soll erst
nach Prüfung und ausdrücklicher Freigabe erstellt werden. In diesem Auftrag wurde
kein `tauri build` ausgeführt.

Browserprüfungen (keine echte Mikrofonaufnahme oder API-Aufrufe):

```powershell
npx playwright install chromium
npm run test:ui
```

Eine reine Browser-Vorschau kann Windows-Credentials, SQLite, Hardware und SAPI
nicht erreichen; die App zeigt dann Nicht-verfügbar-Zustände. Keine Demo-Werte.

## Erstkonfiguration

1. **Neural Console** oder **Einstellungen** öffnen. Einen **neu ausgestellten**
   OpenAI-/Groq-Schlüssel in das Passwortfeld eingeben und sicher speichern.
   Ziel ist Windows Credential Manager, Dienst `JARVIS.Neural.1.3` mit getrennten
   Anbieterkonten. Es gibt keinen Klartext-Fallback und keinen Schlüssel-Lesebefehl.
2. Rechts im Chat Anbieter wählen, **Modelle beim Anbieter abrufen**, ein verfügbares
   Modell auswählen. Eine Modellliste garantiert nicht die Chat-Berechtigung.
   Anschließend **Verbindung & Modell testen**: prüft Modellliste und echte kleine
   Textanfrage, kann also API-Kosten verursachen. Es gibt kein festes Standardmodell.
3. In der Console pro Anbieter Timeout (5–120 Sekunden) und zusätzliche Versuche
   (0–3; Standard 0) festlegen und **Provider-Optionen speichern** wählen.
4. Eine Nachricht erstellen. **Versandvorschau erstellen** prüft lokal, welche
   Nachrichten und Wissensabschnitte übertragen würden. Erst die separate
   **Cloud-Versandbestätigung** sendet. Anfrage, Modellabfrage und Verbindungstest
   können abgebrochen werden; bereits serverseitig ausgeführte Arbeit lässt sich
   dadurch nicht zurückholen und kann trotzdem Kosten verursachen.
5. Optional einen anderen Anbieter als Ausweichziel wählen. Dessen Schlüssel und
   Modell separat einrichten. Die konkrete Weiterleitung muss in jeder Vorschau
   ausdrücklich freigegeben werden. 401/403/Modellfehler lösen keinen Wechsel aus.

Alte `.env`-/Umgebungsschlüssel werden **nicht übernommen**. Die alten Groq-Befehle
bleiben vorhanden, verwenden aber die neue sichere Speicherung und gewählte Modelle.
Schlüssel nie in Chat, Wissensnotizen, Exporte oder Projektdateien eintragen.

## Bewusstes lokales Wissen und RAG

- Notizen explizit speichern; Kategorien Projekt, Technik, Präferenz,
  Dokumentation, WoW Forever und Wissen.
- TXT/Markdown (UTF-8) und PDFs mit extrahierbarem Text lokal importieren.
  Pro Datei maximal 10 MB, extrahierter Inhalt maximal 500.000 Zeichen. Keine OCR.
- Für WoW eigene Raid-/Boss-/Klassen-/Rollen-/Spielversions- und Quellenmetadaten
  eintragen. Keine automatischen Server-News oder erfundenen Spielinformationen.
- Suche durchsucht Inhalt, Titel und Metadaten. FTS5-RAG verwendet maximal fünf
  Textabschnitte mit echten Zeichenpositionen im extrahierten Dokumenttext.
- Dokument-Cloud-Verarbeitung ist standardmäßig aus. Zur Verwendung aktivieren
  und zusätzlich die konkrete Vorschau bestätigen. Wissenssuche lässt sich für
  den aktuellen Chat ausschalten.
- Einträge bearbeiten/löschen, Gedächtnis als JSON exportieren/importieren.
  Import fügt hinzu und überschreibt keine vorhandenen IDs. Vollständiges Löschen
  verlangt `ALLES LÖSCHEN` und entfernt auch gespeicherte Chats und den FTS-Index.
- Chat-Persistenz ist standardmäßig aus. Bei bewusstem Opt-in werden nur bestätigte
  Fragen und erfolgreiche Antworten gespeichert. Sie können separat angezeigt und
  exportiert und durch vollständiges Gedächtnislöschen entfernt werden. Sie werden
  nicht automatisch als RAG-Kontext genutzt. Der Chat-Export ist kein automatischer
  Gedächtnisimport.

Der Datenbankpfad wird über Tauri `app_data_dir()` bestimmt; Datei `neural.sqlite3`.
API-Schlüssel liegen separat im Betriebssystem. Die Wissensdatenbank und ihre
Exporte sind nicht verschlüsselt; Windows-Konto und Geräteschutz sind relevant.

## Dokumentation

- Vorabplan: `docs/ARCHITEKTUR_1.3.md`
- Architektur und Grenzen: `docs/NEURAL_ARCHITEKTUR.md`
- Neue Rust-Befehle und kompatible Altbefehle: `docs/RUST_BEFEHLE_1.3.md`
- Datenschutz und Kosten: `docs/DATENSCHUTZ_KOSTEN.md`
- Frische Prüfergebnisse/offene Tests: `docs/TESTBERICHT_1.3.md`
- Änderungen: `CHANGELOG_1.3.0.md`

Die Dateien zu 1.2 dokumentieren den historischen HUD-/Voice-Ausgangspunkt. Für
Schlüsselverwaltung und KI-Versand gilt jetzt diese 1.3-Dokumentation.
