import { useEffect, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { Activity, ArrowDown, ArrowUpRight, AudioLines, Bot, ChevronRight, CircleHelp, Clock3, Cpu, Database, Globe2, HardDrive, LayoutDashboard, MessageSquare, Radio, RefreshCw, Send, Settings2, ShieldCheck, Sparkles, Thermometer, Zap, type LucideIcon } from 'lucide-react';
import { HudCore } from './HudCore';
import { useBackend } from './useBackend';
import { useVoice } from './useVoice';
import { VoiceControls } from './VoiceControls';
import { useNeural, safeError, type AiReply } from './useNeural';
import { NeuralConsole, NeuralSelector, NeuralReview } from './NeuralConsole';
import { chartSegments, format, ramPercent, unavailable, type Sample } from './telemetry';

type Page = 'overview' | 'system' | 'ai' | 'wow' | 'activity' | 'neural' | 'settings';
type Message = { who: 'J.A.R.V.I.S.' | 'DU' | 'SYSTEM'; text: string; reply?: AiReply };
type Event = { text: string; at: Date };
const pages: { id: Page; label: string; icon: LucideIcon }[] = [
  { id: 'overview', label: 'Command Center', icon: LayoutDashboard },
  { id: 'system', label: 'Systemmonitor', icon: Cpu },
  { id: 'ai', label: 'KI Intelligence', icon: Globe2 },
  { id: 'wow', label: 'WoW Forever', icon: Sparkles },
  { id: 'activity', label: 'Aktivitätsprotokoll', icon: Activity },
  { id: 'neural', label: 'Neural Console', icon: Bot },
  { id: 'settings', label: 'Einstellungen', icon: Settings2 },
];
function Panel({ title, tag, children, className = '' }: { title: string; tag?: ReactNode; children: ReactNode; className?: string }) {
  return <section className={`panel ${className}`}><div className="panel-heading"><h2>{title}</h2>{tag}</div>{children}</section>;
}
function Header({ backend }: { backend: 'checking' | 'available' | 'unavailable' }) {
  const [now, setNow] = useState(new Date());
  useEffect(() => { const id = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(id); }, []);
  return <header className="topbar">
    <div className={`system-badge ${backend === 'available' ? 'available' : ''}`}><span className="status-dot"/> BACKEND <strong>{backend === 'checking' ? 'ABFRAGE' : backend === 'available' ? 'ERREICHBAR' : 'NICHT VERFÜGBAR'}</strong></div>
    <div className="clock"><span>{now.toLocaleDateString('de-DE', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' })}</span><time dateTime={now.toISOString()}>{now.toLocaleTimeString('de-DE')}</time></div>
    <div className="operator"><ShieldCheck size={17}/><div>Lokaler Workspace<small>WINDOWS COMMAND CENTER</small></div></div>
  </header>;
}
function Metric({ label, value, subtitle, percent, icon: Icon }: { label: string; value: string; subtitle: string; percent: number | null; icon: LucideIcon }) {
  return <article className={`metric panel ${percent === null ? 'unavailable' : ''}`}>
    <div className="metric-title"><Icon size={15}/><span>{label}</span><span className="metric-source">{percent === null ? '—' : 'SYS'}</span></div>
    <div className="metric-content"><svg className="metric-gauge" viewBox="0 0 72 72" aria-hidden="true"><circle className="gauge-track" cx="36" cy="36" r="29"/>{percent !== null && <circle className="gauge-value" cx="36" cy="36" r="29" pathLength="100" strokeDasharray={`${percent} 100`} transform="rotate(-90 36 36)"/>}<circle cx="36" cy="36" r="21" className="gauge-inner"/><text x="36" y="40" textAnchor="middle">{percent === null ? '—' : Math.round(percent)}</text></svg><div><strong className={value === unavailable ? 'missing' : ''}>{value}</strong><p>{subtitle}</p></div></div>
  </article>;
}
function History({ samples, cpu, ram }: { samples: Sample[]; cpu: number | null; ram: number | null }) {
  return <Panel title="Telemetrie / Verlauf" tag={<span className="micro-tag">MAX. 45 MESSUNGEN</span>} className="history-panel"><div className="history-grid">{(['cpu', 'ram'] as const).map(kind => <div key={kind}><div className="history-label"><span>{kind.toUpperCase()}</span><strong>{format(kind === 'cpu' ? cpu : ram, '%')}</strong></div><svg className="history-chart" viewBox="0 0 100 100" preserveAspectRatio="none" role="img" aria-label={`${kind.toUpperCase()}-Messverlauf mit Lücken bei fehlenden Daten`}>
    {[25, 50, 75].map(y => <line key={y} x1="0" x2="100" y1={y} y2={y}/>)}
    {chartSegments(samples, kind).map((points, i) => <polyline key={i} points={points}/>)}
  </svg></div>)}</div><p className="panel-note">Nur erfasste Werte · Lücken werden nicht interpoliert.</p></Panel>;
}
function App() {
  const [page, setPage] = useState<Page>('overview');
  const { telemetry, samples, updated, error, polling, refresh } = useBackend();
  const neural = useNeural();
  const [messages, setMessages] = useState<Message[]>([]);
  const [events, setEvents] = useState<Event[]>(() => [{ text: 'Oberfläche gestartet', at: new Date() }]);
  const [draft, setDraft] = useState('');
  const [sending, setSending] = useState(false);
  const [voiceDraft, setVoiceDraft] = useState(false);
  const chatLog = useRef<HTMLDivElement>(null);
  const input = useRef<HTMLTextAreaElement>(null);
  const mounted = useRef(false);
  const voiceEngine = useVoice(text => {
    if (neural.preview && !neural.sending) neural.cancel();
    setDraft(previous => [previous.trim(), text].filter(Boolean).join('\n'));
    setVoiceDraft(true);
    log('Lokale Sprache erkannt; Bestätigung ausstehend');
  });
  const latestVoice = useRef(voiceEngine); latestVoice.current = voiceEngine;
  useEffect(() => { mounted.current = true; return () => { mounted.current = false; }; }, []);
  useEffect(() => { const log = chatLog.current; if (log) log.scrollTop = log.scrollHeight; }, [messages, sending]);
  function log(text: string) { setEvents(previous => [{ text, at: new Date() }, ...previous].slice(0, 30)); }
  const selectedProvider = neural.status?.preferences.selected ?? 'groq';
  const selectedConfig = neural.status?.preferences[selectedProvider];
  const ai = neural.status ? { ready: neural.status.keys[selectedProvider] && !!selectedConfig?.model, provider: selectedProvider === 'openai' ? 'OpenAI' : 'Groq' } : null;
  async function send(event: FormEvent) {
    event.preventDefault();
    if (!draft.trim() || sending || neural.preparing || !ai?.ready || (voiceEngine.running && voiceEngine.snapshot?.mode !== 'speak')) return;
    await neural.prepare(draft.trim());
  }
  async function confirmSend(documents: boolean, fallback: boolean) {
    const prepared = neural.preview;
    if (!prepared || sending) return;
    const text = prepared.preview.question;
    setDraft(''); setVoiceDraft(false); setSending(true);
    setMessages(previous => [...previous, { who: 'DU', text }]);
    try {
      const reply = await neural.send(documents, fallback);
      if (!mounted.current) return;
      setMessages(previous => [...previous, { who: 'J.A.R.V.I.S.', text: reply.text, reply }]);
      log(`KI-Antwort empfangen: ${reply.provider} / ${reply.model}`);
      if (latestVoice.current.ttsEnabled) void latestVoice.current.startSpeaking(reply.text);
    } catch (reason) {
      if (mounted.current) { setMessages(previous => [...previous, { who: 'SYSTEM', text: safeError(reason) }]); log('KI-Anfrage beendet oder fehlgeschlagen'); }
    } finally { if (mounted.current) setSending(false); }
  }
  const ram = ramPercent(telemetry);
  const cpu = telemetry?.cpu_percent ?? null;
  const aiLabel = ai === null ? 'Status nicht verfügbar' : ai.ready ? `${ai.provider} · Konfiguriert` : `${ai.provider} · Nicht konfiguriert`;
  const goToChat = () => { input.current?.focus(); input.current?.scrollIntoView({ block: 'nearest', behavior: 'instant' }); };
  const metrics = <div className="metric-grid">
    <Metric label="CPU" value={format(cpu, '%')} percent={cpu} subtitle={telemetry?.cpu_name ?? unavailable} icon={Cpu}/>
    <Metric label="GPU" value={format(telemetry?.gpu_percent, '%')} percent={telemetry?.gpu_percent ?? null} subtitle="Keine integrierte Sensorquelle" icon={Activity}/>
    <Metric label="RAM" value={format(ram, '%')} percent={ram} subtitle={telemetry?.ram_used_gb != null && telemetry.ram_total_gb != null ? `${format(telemetry.ram_used_gb, 'GiB')} / ${format(telemetry.ram_total_gb, 'GiB')}` : unavailable} icon={Database}/>
    <Metric label="SPEICHER" value={unavailable} percent={null} subtitle="Keine integrierte Laufwerksquelle" icon={HardDrive}/>
  </div>;
  const systemDetails = <div className="details">
    <div><span>Betriebssystem</span><strong>{telemetry?.os_name ?? unavailable}</strong></div>
    <div><span>CPU-Temperatur</span><strong>{format(telemetry?.cpu_temp_c, '°C')}</strong></div>
    <div><span>GPU-Temperatur</span><strong>{format(telemetry?.gpu_temp_c, '°C')}</strong></div>
    <div><span>Letzte erfolgreiche Abfrage</span><strong>{updated?.toLocaleTimeString('de-DE') ?? unavailable}{error && updated ? ' · veraltet' : ''}</strong></div>
  </div>;
  return <div className="app-shell">
    <a className="skip-link" href="#main-content">Zum Inhalt</a>
    <aside className="sidebar"><div className="brand"><div className="brand-reactor" aria-hidden="true"><i/></div><div><strong>JARVIS</strong><span>COMMAND CENTER</span></div></div>
      <div className="nav-caption">PERSONAL WORKSPACE <span>01</span></div><nav aria-label="Hauptnavigation">{pages.map(({ id, label, icon: Icon }) => <button key={id} className={`nav-link ${page === id ? 'active' : ''}`} aria-current={page === id ? 'page' : undefined} onClick={() => setPage(id)} title={label}><Icon size={17}/><span>{label}</span>{page === id && <ChevronRight size={13}/>}</button>)}</nav>
      <div className="sidebar-bottom"><div className="voice-card"><AudioLines size={25}/><span>SPRACHSTEUERUNG</span><strong>{voiceEngine.recording ? 'Aufnahme läuft' : voiceEngine.permission ? 'Mikrofon freigegeben' : 'Mikrofon gesperrt'}</strong><p>Lokales Push-to-Talk · de-DE</p><button className="secondary-button" onClick={goToChat}><MessageSquare size={14}/> Zum Chat</button></div><div className="version"><span>J.A.R.V.I.S. / 1.3.0</span><small>REACT · TAURI 2 · RUST</small></div></div>
    </aside>
    <Header backend={telemetry ? 'available' : polling ? 'checking' : 'unavailable'}/>
    <main id="main-content" className="workspace" tabIndex={-1}>
      <div className="page-heading"><div><span className="eyebrow">J.A.R.V.I.S. / PERSONAL COMMAND CENTER</span><h1>{pages.find(item => item.id === page)?.label}</h1></div><span className="micro-tag">LOKALE TELEMETRIE · 4 S NACH ABFRAGE</span></div>
      <div className="dashboard-grid"><div className="command-column">
        {error && <div className="backend-error" role="status"><Radio size={16}/><span>{error}</span></div>}
        {page === 'overview' && <>
          <Panel title="Neural Intelligence Core" tag={<Bot size={14}/>}><div className="neural-stat-grid"><span>Dokumente: {neural.status?.stats.documents ?? 'Nicht verfügbar'}</span><span>Wissen: {neural.status?.stats.entries ?? 'Nicht verfügbar'}</span><span>Provider: {ai?.provider ?? 'Nicht verfügbar'}</span></div><button className="text-button" onClick={() => setPage('neural')}>Gedächtnis, Quellen & Datenschutz öffnen <ChevronRight size={12}/></button></Panel>
          <div className="hero-grid"><Panel title="Core Overview" className="core-overview" tag={<span className="corner-number">01</span>}>
            <div className="overview-item"><Cpu/><div><span>Systemzugriff</span><strong>{telemetry ? 'Abfrage erfolgreich' : polling ? 'Wird geprüft …' : unavailable}</strong></div></div>
            <div className="overview-item"><Bot/><div><span>KI-Konfiguration</span><strong>{aiLabel}</strong></div></div>
            <div className="overview-item"><Database/><div><span>Arbeitsspeicher</span><strong>{format(telemetry?.ram_total_gb, 'GiB')}</strong></div></div>
            <div className="overview-item"><Thermometer/><div><span>CPU-Sensor</span><strong>{format(telemetry?.cpu_temp_c, '°C')}</strong></div></div>
            <p className="panel-note">Konfiguration bestätigt keine Online-Verbindung.</p>
          </Panel><HudCore voiceState={voiceEngine.snapshot?.state ?? (voiceEngine.running ? 'starting' : 'idle')} level={voiceEngine.level}/></div>
          {metrics}
          <div className="lower-grid"><History samples={samples} cpu={cpu} ram={ram}/><Panel title="Systemstatus" tag={<ShieldCheck size={14}/>}>{systemDetails}</Panel></div>
          <Panel title="Schnellaktionen" tag={<Zap size={14}/>} className="quick-panel"><div className="quick-actions">
            <button onClick={goToChat}><MessageSquare/><span>KI-Chat öffnen<small>Texteingabe fokussieren</small></span><ArrowUpRight/></button>
            <button onClick={() => { refresh(); log('Manuelle Aktualisierung angefordert'); }} disabled={polling}><RefreshCw/><span>Neu abfragen<small>Hardware & KI-Status</small></span><ArrowUpRight/></button>
            <button onClick={() => setPage('system')}><Cpu/><span>Systemdetails<small>Messwerte & Sensoren</small></span><ArrowUpRight/></button>
            <button onClick={() => setPage('settings')}><Settings2/><span>Konfiguration<small>Lokale Groq-Einrichtung</small></span><ArrowUpRight/></button>
          </div></Panel>
        </>}
        {page === 'system' && <>{metrics}<History samples={samples} cpu={cpu} ram={ram}/><Panel title="Hardware / Quellen">{systemDetails}<p className="panel-note">CPU und RAM: native Systemabfragen über Rust/sysinfo. GPU, Temperaturen und Laufwerke ohne integrierten Anbieter: Nicht verfügbar. Keine Demo-Werte.</p><button className="secondary-button" onClick={refresh} disabled={polling}><RefreshCw size={14}/> Jetzt aktualisieren</button></Panel></>}
        {page === 'ai' && <Panel title="KI Intelligence" className="module-panel"><Globe2 className="module-icon"/><h3>Information braucht eine Quelle.</h3><p>Ein Nachrichtendienst ist noch nicht angebunden. Es werden keine Schlagzeilen oder Online-Meldungen erzeugt.</p><div className="empty-state">News-Feed: {unavailable}</div><button className="secondary-button" onClick={goToChat}><MessageSquare size={14}/> Groq-Chat öffnen</button></Panel>}
        {page === 'wow' && <Panel title="WoW Forever" className="module-panel"><Sparkles className="module-icon"/><h3>Dein Community-Bereich.</h3><p>Raidplanung, Klassenwissen und Community-News benötigen eine angebundene Quelle.</p><div className="empty-state">Externe Community-Daten: {unavailable}</div><button className="secondary-button" onClick={() => setPage('neural')}>Eigene WoW-Forever-Guides verwalten</button></Panel>}
        {page === 'activity' && <Panel title="Lokales Sitzungsprotokoll" className="module-panel"><p className="panel-note">Nur tatsächlich ausgelöste App-Ereignisse; keine Nachrichtentexte oder API-Schlüssel. Wird nicht dauerhaft gespeichert.</p><ol className="event-list">{events.map((event, i) => <li key={i}><Clock3 size={13}/><time>{event.at.toLocaleTimeString('de-DE')}</time><span>{event.text}</span></li>)}</ol></Panel>}
        {page === 'neural' && <NeuralConsole neural={neural}/>}
        {page === 'settings' && <NeuralConsole neural={neural}/>}
      </div>
      <aside className="intelligence-column" aria-label="KI-Assistent und Informationsstatus">
        <Panel title="J.A.R.V.I.S. / KI-Chat" tag={<MessageSquare size={14}/>} className="chat-panel">
          <NeuralSelector neural={neural}/><div className="assistant-header"><div className="assistant-icon"><Bot size={23}/></div><div><strong>Dein KI-Assistent</strong><span>{aiLabel}</span></div></div>
          <p className="chat-disclaimer">{ai?.ready ? 'Schlüssel und Modell gewählt. Verbindung wird beim bestätigten Senden geprüft.' : ai === null ? 'KI-Status konnte noch nicht bestätigt werden.' : 'Provider, sicheren Schlüssel und Modell in der Neural Console einrichten.'}</p>
          <div className="chat-log" role="log" aria-label="Chatverlauf" aria-live="polite" ref={chatLog}>{messages.length === 0 ? <div className="chat-empty"><MessageSquare size={28}/><span>Wie kann ich dir helfen?</span><p>Hier erscheinen ausschließlich deine Nachrichten und tatsächliche Backend-Antworten.</p></div> : messages.map((message, i) => <div key={i} className={`bubble ${message.who === 'DU' ? 'mine' : message.who === 'SYSTEM' ? 'chat-error' : ''}`}><span>{message.who}</span><p>{message.text}</p>{message.reply && <div className="answer-sources">{message.reply.storage_warning&&<p className="voice-error">{message.reply.storage_warning}</p>}<strong>{message.reply.provider} / {message.reply.model}{message.reply.fallback_used ? ' · freigegebener Ausweichanbieter' : ''}</strong><small>{message.reply.sources.length ? 'Übermittelter lokaler Kontext (Modellbelege bitte prüfen)' : 'KI-Modellwissen · keine aktuelle Webrecherche'}</small>{message.reply.sources.map(source => <details key={source.label}><summary>[{source.label}] {source.source || source.title} · Zeichen {source.start_char + 1}–{source.end_char}</summary><p>{source.text}</p><small>Stand: {source.updated} · {Object.entries(source.metadata ?? {}).map(([key,value]) => `${key}: ${value}`).join(' · ')}</small></details>)}</div>}</div>)}{sending && <div className="sending" role="status">KI-Anfrage wird verarbeitet …</div>}</div>
          {voiceDraft && <p className="voice-confirmation" role="status">Sprache erkannt. Text prüfen und bearbeiten; erst die anschließende Cloud-Versandbestätigung überträgt ihn an den gewählten Anbieter.</p>}
          <form className="chat-form" onSubmit={send}><label className="sr-only" htmlFor="chat-message">Nachricht an J.A.R.V.I.S.</label><textarea id="chat-message" ref={input} value={draft} maxLength={8000} rows={2} onChange={event => { if (neural.preview && !neural.sending) neural.cancel(); setDraft(event.target.value); }} placeholder="Nachricht an J.A.R.V.I.S. …" onKeyDown={event => { if (event.key === 'Enter' && !event.shiftKey && !event.nativeEvent.isComposing) { event.preventDefault(); event.currentTarget.form?.requestSubmit(); } }}/><div className="composer-footer"><span>{sending ? 'Warte auf Antwort' : 'ENTER VORSCHAU · ⇧ ENTER UMBRUCH'}</span><button type="submit" disabled={sending || neural.preparing || !draft.trim() || !ai?.ready || (voiceEngine.running && voiceEngine.snapshot?.mode !== 'speak')} aria-label={voiceDraft ? 'Erkannten Text zur Versandprüfung vorbereiten' : 'Versandvorschau erstellen'} title="Lokale Versandvorschau erstellen"><Send size={15}/></button></div></form>
          {neural.preparing && <p role="status">Lokale Versandvorschau wird erstellt …</p>}
          {neural.preview && <NeuralReview key={neural.preview.preview.id} neural={neural} onConfirm={(documents, fallback) => void confirmSend(documents, fallback)}/>}
          {sending && <button className="secondary-button" onClick={neural.cancel}>KI-Anfrage abbrechen</button>}
          <VoiceControls engine={voiceEngine}/>
        </Panel>
        <Panel title="Intelligence Feed" tag={<span className="micro-tag">QUELLEN</span>} className="feed-panel"><div className="feed-status"><Globe2 size={19}/><div><strong>Nachrichten</strong><span>{unavailable}</span></div></div><p className="panel-note">Kein News-Dienst angebunden.</p><button className="text-button" onClick={() => setPage('ai')}>Quellenstatus anzeigen <ChevronRight size={12}/></button></Panel>
      </aside></div>
    </main>
    <footer className="news-ticker" aria-label="Nachrichtenstatus"><span className="ticker-label"><Radio size={14}/> NEWS-TICKER</span><span className="ticker-copy">Nicht verfügbar <span>· Keine Nachrichtenquelle angebunden</span></span><button onClick={() => setPage('ai')} aria-label="Informationen zur Nachrichtenquelle"><CircleHelp size={15}/></button><span className="footer-version">J.A.R.V.I.S. 1.3.0 <ArrowDown size={12}/></span></footer>
  </div>;
}
export default App;
