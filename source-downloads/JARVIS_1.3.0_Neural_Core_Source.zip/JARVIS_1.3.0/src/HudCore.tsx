import { memo } from 'react';
// Decorative cartographic silhouette, never a representation of live network activity.
const land = [
  'M-148,-52 -130,-65 -106,-71 -81,-60 -61,-49 -75,-30 -89,-17 -102,-24 -114,-32 -130,-31 Z',
  'M-81,-11 -68,-5 -52,3 -37,11 -41,30 -54,48 -68,55 -73,32 -78,13 Z',
  'M-18,-35 -2,-37 15,-31 31,-13 39,6 27,30 14,35 4,16 -9,4 -16,-15 Z',
  'M-9,-43 1,-54 21,-62 42,-54 61,-61 85,-53 109,-51 139,-36 127,-16 108,-13 91,1 75,8 54,-6 41,-28 25,-29 14,-39 Z',
  'M104,25 122,20 143,29 151,43 131,49 115,41 Z',
  'M-55,-75 -32,-77 -28,-63 -46,-56 Z',
];
export const HudCore = memo(function HudCore({ voiceState = 'idle', level = null }: { voiceState?: string; level?: number | null }) {
  return <section className={`hud-core voice-${voiceState}`} aria-label="Animierter J.A.R.V.I.S.-Kern mit dekorativer Weltkugel">
    <div className="stage-grid" aria-hidden="true"/>
    <div className="stage-coordinate top-left">VISUAL INTERFACE / 1.3.0</div>
    <div className="stage-coordinate top-right">LOCAL COMMAND CORE</div>
    <svg className="globe" viewBox="0 0 600 360" aria-hidden="true">
      <defs>
        <radialGradient id="sphere"><stop offset="0" stopColor="#125169" stopOpacity=".32"/><stop offset=".8" stopColor="#063346" stopOpacity=".2"/><stop offset="1" stopColor="#31c9e6" stopOpacity=".12"/></radialGradient>
        <clipPath id="globe-clip"><circle cx="300" cy="164" r="131"/></clipPath>
        <linearGradient id="orbit"><stop stopColor="#34e7f0" stopOpacity="0"/><stop offset=".5" stopColor="#34e7f0" stopOpacity=".7"/><stop offset="1" stopColor="#34e7f0" stopOpacity="0"/></linearGradient>
      </defs>
      <g className="globe-mesh">
        <circle cx="300" cy="164" r="131" fill="url(#sphere)" stroke="#36d8e5" strokeOpacity=".45"/>
        <g clipPath="url(#globe-clip)" fill="none" stroke="#3493ac" strokeWidth=".65" opacity=".65">
          {[-110,-85,-48,0,48,85,110].map(y => <ellipse key={`lat${y}`} cx="300" cy={164+y} rx={Math.sqrt(131**2-y**2)} ry="13"/>)}
          {[25,55,85,112,130].map(rx => <ellipse key={`long${rx}`} cx="300" cy="164" rx={rx} ry="131"/>)}
          {land.map((d,i) => <path key={i} d={d} transform="translate(300 164) scale(.82 1.35)" fill="#1b8b9c" fillOpacity=".27" stroke="#50cbd7" strokeOpacity=".65"/>)}
          {[-100,-60,-20,20,60,100].map(x => <path key={x} d={`M${300+x},25 Q${300-x},164 ${300+x},303`}/>)}
        </g>
      </g>
      <g className="orbital-lines" fill="none" stroke="url(#orbit)">
        <ellipse cx="300" cy="164" rx="237" ry="57" transform="rotate(-18 300 164)"/>
        <ellipse cx="300" cy="164" rx="211" ry="80" transform="rotate(22 300 164)"/>
        <circle cx="300" cy="164" r="145" strokeDasharray="1 11" strokeOpacity=".4"/>
      </g>
      <g className="reactor-ring" fill="none" stroke="#57f3f2">
        <circle cx="300" cy="164" r="100" strokeWidth="3" strokeDasharray="40 9 5 9 22 28" opacity=".7"/>
        <circle cx="300" cy="164" r="91" strokeWidth="1" strokeDasharray="2 7" opacity=".6"/>
      </g>
      <g className="reactor-ring reverse" fill="none" stroke="#4ed3e8"><circle cx="300" cy="164" r="112" strokeWidth="1" strokeDasharray="120 60 20 70"/></g>
      {level !== null && <circle className="native-level-ring" cx="300" cy="164" r="151" fill="none" stroke="#83fff0" strokeWidth="3" pathLength="100" strokeDasharray={`${level} 100`} transform="rotate(-90 300 164)"/>}
      <g className="ground" fill="none" stroke="#2fa7bf" strokeWidth=".65">
        {[170,150,130,110,90,70].map(rx => <ellipse key={rx} cx="300" cy="309" rx={rx} ry={rx/8}/>)}
      </g>
      <g fill="#88ffff" className="orbit-lights"><circle cx="95" cy="195" r="2.5"/><circle cx="477" cy="210" r="3"/><circle cx="400" cy="75" r="2"/><circle cx="185" cy="93" r="2"/></g>
    </svg>
    <div className="core-wordmark"><h2>JARVIS</h2><span>PERSONAL AI CORE</span><small>{voiceState === 'listening' ? 'MIKROFON AKTIV' : voiceState === 'speaking' ? 'LOKALE SPRACHAUSGABE' : voiceState === 'starting' ? 'SPRACHENGINE STARTET' : voiceState === 'finishing' ? 'ERKENNUNG ABSCHLIESSEN' : 'INTERFACE 1.3.0'}</small>{voiceState === 'listening' && <span className="core-audio-level">{level === null ? 'Eingangspegel: Nicht verfügbar' : `Eingangspegel: ${level} %`}</span>}</div>
    <div className="core-caption"><span className="tiny-cross">+</span> VISUALISIERUNG · KEINE LIVE-KARTE <span className="tiny-cross">+</span></div>
  </section>;
});
